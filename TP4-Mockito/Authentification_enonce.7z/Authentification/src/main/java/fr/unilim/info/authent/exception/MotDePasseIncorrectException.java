package fr.unilim.info.authent.exception;

public class MotDePasseIncorrectException extends Exception {

	public MotDePasseIncorrectException(String message) {
		super(message);
	}

}
