package fr.unilim.info.authent.exception;

public class CompteInactifException extends Exception {

	public CompteInactifException(String message) {
		super(message);
	}

}
