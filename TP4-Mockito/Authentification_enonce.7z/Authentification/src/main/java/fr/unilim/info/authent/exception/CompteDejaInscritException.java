package fr.unilim.info.authent.exception;

public class CompteDejaInscritException extends Exception {

	public CompteDejaInscritException(String message) {
		super(message);
	}

}
