package fr.unilim.info.authent.exception;

public class CompteInexistantException extends Exception {

	public CompteInexistantException(String message) {
		super(message);
	}

}
